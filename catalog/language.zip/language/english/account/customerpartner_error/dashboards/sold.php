<?php
// Heading
$_['heading_title'] = 'Jumlah Terjual';

// Text
$_['text_view']     = 'Lihat lebih banyak';
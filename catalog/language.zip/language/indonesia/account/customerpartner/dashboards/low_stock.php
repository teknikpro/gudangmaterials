<?php
// Heading
$_['heading_title'] = 'Low Stocks';

// Text
$_['text_view']     = 'View more...';
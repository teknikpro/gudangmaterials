<?php
// heading
$_['heading_title'] = 'Gunakan Kode Kupon';

// Text
$_['text_coupon'] = 'Kupon (%s)';
$_['text_success']  = 'Sukses: Kupon diskon Anda telah diaplikasikan!';

// Entry
$_['entry_coupon']  = 'Masukkan kupon Anda disini';

// Error
$_['error_coupon']  = 'Perhatian: Kupon tidak valid, expired atau telah digunakan melebihi batas!';
$_['error_empty']   = 'Perhatian: Mohon masukkan kode kupon Anda!';

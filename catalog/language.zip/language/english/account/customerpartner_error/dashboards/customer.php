<?php
// Heading
$_['heading_title'] = 'Total Pembeli';

// Text
$_['text_view'] = 'Lihat lebih banyak';
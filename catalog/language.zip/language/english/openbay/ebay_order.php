<?php
// Text
$_['text_total_shipping']		= 'Pengiriman';
$_['text_total_discount']		= 'Discount';
$_['text_total_tax']			= 'Pajak';
$_['text_total_sub']			= 'Sub-total';
$_['text_total']				= 'Jumlah';
$_['text_smp_id']				= 'Selling Manager sale ID: ';
$_['text_buyer']				= 'Buyer username: ';
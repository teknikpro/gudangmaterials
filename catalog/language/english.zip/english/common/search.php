<?php
// Text
$_['text_search'] = 'cari';
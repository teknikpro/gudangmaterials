<?php
// Heading
$_['heading_title']      = 'Transaksi Anda';

// Column
$_['column_date_added']  = 'Tanggal Ditambahkan';
$_['column_description'] = 'Deskripsi';
$_['column_amount']      = 'Jumlah (%s)';

// Text
$_['text_account']       = 'Akun';
$_['text_transaction']   = 'Transaksi Anda';
$_['text_total']         = 'Saldo Anda saat ini adalah:';
$_['text_empty']         = 'Anda belum memiliki transaksi apapun!';
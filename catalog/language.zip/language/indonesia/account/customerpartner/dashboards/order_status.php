<?php

// Text
$_['text_order_complete']    = 'Order Completed';
$_['text_order_processing']  = 'Order Processing';
$_['text_order_cancel']      = 'Order Canceled';

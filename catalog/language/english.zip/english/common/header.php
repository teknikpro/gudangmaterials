<?php
// Text
$_['text_home']          = 'Beranda';
$_['text_wishlist']      = 'Daftar Permintaan (%s)';
$_['text_shopping_cart'] = 'Keranjang Belanja';
$_['text_category']      = 'Kategori';
$_['text_account']       = 'Akun Saya';
$_['text_register']      = 'Daftar';
$_['text_login']         = 'Log Masuk';
$_['text_order']         = 'Riwayat Pemesanan';
$_['text_transaction']   = 'Transaksi';
$_['text_download']      = 'Unduhan';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Kasir';
$_['text_search']        = 'Cari';
$_['text_all']           = 'Lihat Semua';
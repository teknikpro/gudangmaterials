<?php
// Text
$_['text_items']    = '%s item(s) - %s';
$_['text_empty']    = 'Daftar belanja Anda kosong!';
$_['text_cart']     = 'Lihat Keranjang';
$_['text_checkout'] = 'Kasir';
$_['text_recurring']  = 'Profil Pembayaran';
<?php
// Heading
$_['heading_title']    = 'Pelacakan Afiliasi';

// Text
$_['text_account']     = 'Account';
$_['text_description'] = 'Untuk memastikan Anda dibayar untuk referal yang Anda kirimkan kepada kami, kami perlu melacak referal dengan menempatkan kode pelacakan pada URL yang menghubungkan kami. Anda dapat menggunakan tools dibawah ini untuk menghasilkan links yang mengarah ke %s website.';

// Entry
$_['entry_code']       = 'Kode Tracking Anda';
$_['entry_generator']  = 'Generator Link Tracking';
$_['entry_link']       = 'Link Tracking';

// Help
$_['help_generator']  = 'Ketik nama produk yang ingin Anda link ke';
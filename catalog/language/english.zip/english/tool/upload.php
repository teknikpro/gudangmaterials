<?php
// Text
$_['text_upload']    = 'File anda berhasil diunggah!';

// Error
$_['error_filename'] = 'Nama File harus antara 3 dan 128 karakter!';
$_['error_filetype'] = 'Jenis berkas tidak valid!';
$_['error_upload']   = 'Upload Diperlukan!';

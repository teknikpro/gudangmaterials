<?php
// Text
$_['text_title']				= 'Transfer Bank';
$_['text_instruction']			= 'Instruksi Transfer Bank';
$_['text_description']			= 'Silakan transfer jumlah total ke rekening bank berikut ini.';
$_['text_payment']				= 'Pesanan anda tidak akan kami kirim sampai kami menerima pembayaran.';
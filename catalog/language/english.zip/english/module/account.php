<?php
// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_register']    = 'Daftar';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Lupa Kata Sandi';
$_['text_account']     = 'Akun Saya';
$_['text_edit']        = 'Edit Account';
$_['text_password']    = 'Kata Sandi';
$_['text_address']     = 'Address Books';
$_['text_wishlist']    = 'Daftar keinginan';
$_['text_order']       = 'Riwayat Pemesanan';
$_['text_download']    = 'Unduhan';
$_['text_reward']      = 'Poin Hadiah';
$_['text_return']      = 'Pengembalian';
$_['text_transaction'] = 'Transaksi';
$_['text_newsletter']  = 'Newsletter';
$_['text_recurring']   = 'Pembayaran berkala';
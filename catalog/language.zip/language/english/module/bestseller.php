<?php
// Heading
$_['heading_title'] = 'Terlaris';

// Text
$_['text_tax']      = 'Tanpa Pajak:';
<?php
// Heading
$_['heading_title'] = 'Pilih Toko';

// Text
$_['text_default']  = 'Standar';
$_['text_store']    = 'Silakan pilih toko yang anda ingin kunjungi.';
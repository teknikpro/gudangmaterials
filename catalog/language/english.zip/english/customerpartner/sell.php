<?php
// Heading
$_['heading_title'] = 'Jual';

//Text
$_['text_tax'] = 'Pajak: ';
$_['text_from'] = 'Dari';
$_['text_seller'] = 'Penjual';
$_['text_total_products'] = 'Total produk';
$_['text_long_time_seller'] = 'Lama waktu Penjual';
$_['text_latest_product'] = 'Produk terbaru';
$_['text_sort'] = 'Sortir';
$_['text_limit'] = 'Batas';
$_['text_small_list'] = 'Daftar kecil';
$_['text_gallery'] = 'Galeri';
$_['text_default'] = 'Standar';
$_['text_compare'] = 'Produk membandingkan (%s)';
$_['text_name_asc'] = 'Nama (A-Z)';
$_['text_name_desc'] = 'Nama (Z-A)';
$_['text_price_asc'] = 'Harga (rendah > tinggi)';
$_['text_price_desc'] = 'Harga (tinggi > rendah)';
$_['text_rating_desc']	= 'Rating (Tertinngi)';
$_['text_rating_asc'] = 'Rating (Terendah)';
$_['text_model_asc'] = 'Model (A-Z)';
$_['text_model_desc'] = 'Model (Z-A)';
?>
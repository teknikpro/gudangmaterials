<?php
// Heading 
$_['heading_title']     = 'Koleksi';
$_['text_no_products']	= 'Saat ini tidak ada produk yang tersedia dari Penjual ini.';
?>

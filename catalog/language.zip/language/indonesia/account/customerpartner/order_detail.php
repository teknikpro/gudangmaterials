<?php
// Heading 
$_['heading_title']         = 'Your Order details';

// Text
$_['text_account']          = 'Account';
$_['text_orderdetaillist']  = 'Your Order details list';
$_['text_added_date']       = 'Date Added';
$_['text_comment']          = 'Comment';
$_['text_orderstatus']      = 'Order Status';
$_['text_no_results']       = 'No Result';
$_['text_orderinfo']        = 'Order Information';


?>

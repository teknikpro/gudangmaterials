<?php 
 
//heading 

$_['heading_title']		        =	'Custom Field';
$_['heading_title_insert']		=	'Custom Field Insert';
$_['heading_title_list']		=	'Custom Field List';
$_['heading_title_edit']		=	'Custom Field Edit';

//text

$_['noOption']			=	'Tidak Ada Opsi Ditemukan';
$_['button_update']		=	'Update';
$_['text_field_name']	=	'Nama Field:';
$_['text_desc']			=	'Deskripsi:';
$_['text_is_req']		=	'Diminta';
$_['text_for_seller']	=	'Untuk Penjual:';
$_['text_field_type']	=	'Tipe Field: ';
$_['text_action']		=	'Tindakan';
$_['text_option_value']	=	'Option Value';
$_['text_add_option']	=	'Add Option';
$_['text_remove']		=	'Hapus';
$_['entry_is_required'] =	'<font style="font-weight:bold;color:#F00">&nbsp;*</font>';

//error or success

$_['success_insert']		=	"Berhasil: Anda telah berhasil memasukkan  custom field !";
$_['error_insert']			=	"Peringatan: Silakan isi kolom yang wajib diisi!";
$_['success_update']		=	"Sukses: Anda berhasil memperbarui custom field !";
$_['error_delete']			=	"Peringatan: Silakan pilih setidaknya satu opsi untuk dihapus !";
$_['success_delete']		=	"Berhasil: Anda telah berhasil menghapus field(s) ";

?>
<?php
// Heading
$_['heading_title']     = 'Pesanan Terbaru';

// Column
$_['column_order_id']   = 'Id pemesanan';
$_['column_customer']   = 'Pelanggan';
$_['column_status']     = 'Status';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Tanggal Ditambahkan';
$_['column_action']     = 'Aksi';
<?php
// Text
$_['text_success']     = 'Berhasil: Anda telah mengubah keranjang belanja anda!';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki izin untuk mengakses API!';
$_['error_stock']      = 'Produk yang ditandai dengan *** tidak tersedia dalam jumlah yang diinginkan atau tidak dalam stok!';
$_['error_minimum']    = 'Jumlah minimal pesanan untuk %s adalah %s!';
$_['error_store']      = 'Produk yang anda pilih tidak dapat dibeli!';
$_['error_required']   = '%s diperlukan!';
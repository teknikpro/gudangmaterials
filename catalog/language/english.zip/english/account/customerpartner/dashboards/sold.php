<?php
// Heading
$_['heading_title'] = 'Sold Quantity';

// Text
$_['text_view']     = 'View more...';
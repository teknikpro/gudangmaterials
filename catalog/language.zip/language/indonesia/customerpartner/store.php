<?php
// Heading 
$_['heading_title']     = 'Store';

//Text
$_['text_profile']     = 'View Owner';
$_['text_store']       = 'View Store';
$_['text_collection']  = 'View Full Collection';
$_['text_from']        = "We're from";
$_['text_feedback']    = 'Feedback';
$_['text_connect']     = 'Connect with Us';
$_['text_message']     = 'Send us a message';
$_['text_facebook']    = 'Find us on Facebook';
$_['text_twitter']     = 'Follow us on Twitter';
$_['text_partner']     = 'About Store';
$_['text_our_collection']     = 'Our Collections';
$_['text_more']     = 'See more....';
$_['text_latest_product']     = 'Latest Added Products';

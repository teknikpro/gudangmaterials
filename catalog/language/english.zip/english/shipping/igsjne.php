<?php
// Text
$_['text_title']       = 'Jalur Nugraha Ekakurir (JNE)';
$_['text_description'] = 'Jalur Nugraha Ekakurir (JNE)';
$_['text_days'] = 'day(s)';
$_['error_currency'] = 'JNE using IDR Currency, Please add IDR first';

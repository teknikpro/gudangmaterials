<?php
// heading
$_['heading_title'] = 'Gunakan Kode Voucher';

// Text
$_['text_voucher'] = 'Voucher (%s)';
$_['text_success']  = 'Sukses: Diskon voucher Anda telah berhasil diaplikasikan!';

// Entry
$_['entry_voucher'] = 'Masukkan kode voucher hadiah disini';

// Error
$_['error_voucher'] = 'Perhatian: Voucher tidak valid atau telah digunakan sebelumnya!';
$_['error_empty']   = 'Perhatian: Mohon masukkan kode voucher Anda!';

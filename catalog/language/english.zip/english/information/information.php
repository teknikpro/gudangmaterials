<?php
// Text
$_['text_error'] = 'Halaman Informasi Tidak Ditemukan!';
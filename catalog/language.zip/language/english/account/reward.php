<?php
// Heading
$_['heading_title']      = 'Poin Reward Anda';

// Column
$_['column_date_added']  = 'Tanggal Ditambahkan';
$_['column_description'] = 'Deskripsi';
$_['column_points']      = 'poin';

// Text
$_['text_account']       = 'Akun';
$_['text_reward']        = 'Poin Hadiah';
$_['text_total']         = 'Jumlah poin reward anda adalah:';
$_['text_empty']         = 'Anda tidak memiliki poin reward!';
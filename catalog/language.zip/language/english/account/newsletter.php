<?php
// Heading
$_['heading_title']    = 'Berlangganan Buletin';

// Text
$_['text_account']     = 'Akun';
$_['text_newsletter']  = 'Buletin';
$_['text_success']     = 'Sukses: Langganan buletin anda telah berhasil diperbarui!';

// Entry
$_['entry_newsletter'] = 'Berlangganan';

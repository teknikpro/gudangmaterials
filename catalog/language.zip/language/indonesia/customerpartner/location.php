<?php
// Heading 
$_['heading_title']     = 'Location';
//Text

$_['text_map']	        =	'View Larger Map';

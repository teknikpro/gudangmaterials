<?php
// Heading
$_['heading_title'] = 'Custom Banner Grid';

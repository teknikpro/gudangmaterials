<?php
// Text
$_['text_marketplace']		= 'Marketplace';
$_['text_my_profile']		  = 'Profil saya';
$_['text_addproduct']		  = 'Tambahkan Produk';
$_['text_productlist']		= 'Daftar Produk';
$_['text_dashboard']		  = 'Dashboard';
$_['text_wkshipping']		  = 'Kelola Pengiriman';
$_['text_orderhistory']		= 'Riwayat Pemesanan';
$_['text_transaction']		= 'Transaksi';
$_['text_download']			  = 'Unduhan';
$_['text_ask_admin']		  = 'Tanya ke Admin';
$_['text_ask_seller']		  = 'Hubungi penjual';
$_['text_ask_seller_log']	= 'Silakan Masuk untuk Menghubungi Penjual';
$_['text_profile']			  = 'Profil saya';
$_['text_manageshipping']	= 'Kelola Pengiriman';
$_['text_downloads']		  = 'Unduhan';
$_['text_asktoadmin']		  = 'Tanya ke Admin';
$_['text_notification']		= 'Notifikasi';
$_['text_mode_seller']		= 'Penjual';
$_['text_mode_customer']	= 'Pelanggan';
$_['text_category']	      = 'Kategori';
$_['text_information']	  = 'Informasi';
$_['text_review']	        = 'Ulasan';
$_['text_product']        = 'Produk';

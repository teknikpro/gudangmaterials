<?php
// Heading
$_['heading_title'] = 'Stok Sedikit';

// Text
$_['text_view']     = 'Lihat lebih banyak';
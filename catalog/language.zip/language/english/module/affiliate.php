<?php
// Heading
$_['heading_title']    = 'Affiliasi';

// Text
$_['text_register']    = 'Daftar';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Lupa Kata Sandi';
$_['text_account']     = 'Akun Saya';
$_['text_edit']        = 'Edit Account';
$_['text_password']    = 'Kata Sandi';
$_['text_payment']     = 'Payment Options';
$_['text_tracking']    = 'Pelacakan Afiliasi';
$_['text_transaction'] = 'Transaksi';

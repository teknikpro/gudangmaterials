<?php
################################################################################################
# Seller / Admin mail for Opencart 2.x.x.x From webkul http://webkul.com  	  	       #
################################################################################################

//user 
//for seller mail
$_['text_hello'] = 'Halo';
$_['entry_name'] = 'Nama';
$_['email'] = 'Email';
$_['text_to_admin'] = 'Permintaan Pelanggan untuk jadi Sellership.';
$_['text_to_seller'] = 'Terima kasih atas pendaftaran untuk menjadi Penjual. <br>Kami telah menerima email Anda dan segera kami Follow-up untuk menjadi Penjual setelah memenuhi persyaratan yang telah kami tentukan.';
$_['text_auto'] = ' permintaan Anda telah disetujui. Silahkan login dan mengelola toko Anda.';
$_['text_ur_pre'] = 'Komisi Admin ';
$_['text_sellersubject'] = 'Terima kasih untuk mendaftar sebagai penjual';
$_['text_adminsubject'] = 'Ingin menjadi Penjual';
$_['text_seller_cmnt'] = 'Komentar Pelanggan  -';
$_['text_thanksadmin'] = 'Terima kasih,';


//for product mail

$_['entry_pname'] = 'Nama produk -';
$_['ptext_to_admin'] = 'Permintaan pelanggan untuk produk disetujui.';
$_['ptext_to_seller'] = 'Terima kasih untuk menambahkan produk Anda. <br>Kami telah menerima email Anda dan segera kami approval.';
$_['ptext_auto'] = 'Produk Anda telah disetujui. Silahkan login dan mengelola toko Anda.';
$_['ptext_sellersubject'] = 'Terima kasih untuk menambahkan produk ';
$_['ptext_adminsubject'] = 'Penjual menambahkan produk';

?>

<?php
// Heading
$_['heading_title'] = 'Pelanggan Online';

// Text
$_['text_view']     = 'Lihat lebih banyak';
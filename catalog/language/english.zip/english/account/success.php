<?php
// Heading
$_['heading_title'] = 'Akun anda telah berhasil dibuat!';

// Text
$_['text_message'] = '<p> Selamat! Account baru Anda telah berhasil dibuat! </p> <p> Sekarang Anda dapat mengambil keuntungan dari hak istimewa anggota untuk meningkatkan pengalaman belanja online Anda dengan kami. </p> <p> Jika Anda memiliki pertanyaan tentang pengoperasian toko online, silakan e-mail pemilik toko. </ p> <p> konfirmasi telah dikirim ke alamat e-mail yang disediakan. Jika Anda belum menerimanya dalam waktu satu jam, <a href="%s"> hubungi kami </a> </p>. ';
$_['text_approval'] = '<p> Terima kasih untuk mendaftar dengan% s! </p> <p> Anda akan diberitahu melalui e-mail setelah account Anda telah diaktifkan oleh pemilik toko. </ p> <p> Jika Anda memiliki pertanyaan tentang pengoperasian toko online ini, <a href="%s"> hubungi </a> pemilik toko </p>.';
$_['text_account']  = 'Akun';
$_['text_success']  = 'Berhasil';

<?php
// Heading 
$_['heading_title']         = 'Detail pesanan Anda';

// Text
$_['text_account']          = 'Akun';
$_['text_orderdetaillist']  = 'Daftar detail pesanan Anda';
$_['text_added_date']       = 'Tanggal Ditambahkan';
$_['text_comment']          = 'Komentar';
$_['text_orderstatus']      = 'Status pemesanan';
$_['text_no_results']       = 'Tidak ada hasil';
$_['text_orderinfo']        = 'informasi pemesanan';


?>

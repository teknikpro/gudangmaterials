<?php

// Text
$_['text_order_complete']    = 'Pesanan Selesai';
$_['text_order_processing']  = 'proses pemesanan';
$_['text_order_cancel']      = 'Pesanan Dibatalkan';

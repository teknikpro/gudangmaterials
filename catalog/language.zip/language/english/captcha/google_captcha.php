<?php
// Heading
$_['heading_title'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Masukkan kode itu dalam kotak di bawah ini';

// Error
$_['error_captcha'] = 'Kode verifikasi tidak sesuai dengan gambar!';

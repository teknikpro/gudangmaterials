<?php
// Heading 
$_['heading_title']     = 'Collections';
$_['text_no_products']	= 'Currently no Products available from this Seller.';
?>

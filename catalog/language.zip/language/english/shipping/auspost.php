<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Express';
$_['text_standard'] = 'Standard';
$_['text_eta']      = 'days';
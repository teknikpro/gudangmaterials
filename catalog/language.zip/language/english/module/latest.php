<?php
// Heading
$_['heading_title'] = 'Terbaru';

// Text
$_['text_tax']      = 'Tanpa Pajak:';
<?php
// Text
$_['text_title']       = 'Webkul Custom Shipping';
$_['text_description'] = 'Custom Shipping Rate';
?>
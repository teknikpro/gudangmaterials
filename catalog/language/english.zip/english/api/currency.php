<?php
// Text
$_['text_success']     = 'Sukses: Mata uang Anda telah berubah!';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki izin untuk mengakses API!';
$_['error_currency']   = 'Peringatan: Mata uang kode ini tidak valid!';
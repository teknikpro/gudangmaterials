<?php
$_['text_total'] = 'Jumlah';
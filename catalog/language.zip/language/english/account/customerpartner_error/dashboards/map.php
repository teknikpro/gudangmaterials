<?php
// Heading
$_['heading_title'] = 'Peta Dunia';

$_['text_order']    = 'Pesanan';
$_['text_sale']     = 'Penjualan';
<?php
// Heading
$_['heading_title'] = 'Keluar Akun';

// Text
$_['text_message']  = '<p>Anda Telah keluar dari Akun Afiliasi anda.</p>';
$_['text_account']  = 'Akun';
$_['text_logout']   = 'Logout;
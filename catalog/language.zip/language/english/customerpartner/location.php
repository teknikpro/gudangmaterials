<?php
// HeasdingJudul
$_['heading_title'] = 'Lokasi';
//Text

$_['text_map'] = 'Lihat peta besar';
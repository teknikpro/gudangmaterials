<?php
// Heading
$_['heading_title']    = 'Perbaikan';

// Text
$_['text_maintenance'] = 'Perbaikan';
$_['text_message']     = '<h1 style="text-align:center;">saat ini kami melakukan perbaikan dan pengujian sistim berkala. <br/>Kami akan kembali secepat mungkin. Silakan kunjungi kembali segera.</h1>';
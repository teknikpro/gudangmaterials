<?php
// Heading
$_['heading_title'] = 'Total Penjualan';

// Text
$_['text_view']     = 'Lihat lebih banyak';
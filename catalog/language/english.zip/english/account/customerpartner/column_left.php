<?php
// Text
$_['text_marketplace']		= 'Marketplace';
$_['text_my_profile']		  = 'My Profile';
$_['text_addproduct']		  = 'Add Product';
$_['text_productlist']		= 'Product List';
$_['text_dashboard']		  = 'Dashboard';
$_['text_wkshipping']		  = 'Manage Shipping';
$_['text_orderhistory']		= 'Order History';
$_['text_transaction']		= 'Transactions';
$_['text_download']			  = 'Downloads';
$_['text_ask_admin']		  = 'Ask to Admin';
$_['text_ask_seller']		  = 'Contact Seller';
$_['text_ask_seller_log']	= 'Please Login to Contact Seller';
$_['text_profile']			  = 'My Profile';
$_['text_manageshipping']	= 'Manage Shipping';
$_['text_downloads']		  = 'Downloads';
$_['text_asktoadmin']		  = 'Ask to Admin';
$_['text_notification']		= 'Notifications';
$_['text_mode_seller']		= 'Seller';
$_['text_mode_customer']	= 'Customer';
$_['text_category']	      = 'Category';
$_['text_information']	  = 'Information';
$_['text_review']	        = 'Review';
$_['text_product']        = 'Product';

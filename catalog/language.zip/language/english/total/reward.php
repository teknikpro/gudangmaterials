<?php
// Heading
$_['heading_title'] = 'Gunakan Poin Reward (Tersedia %s)';

// Text
$_['text_reward']   = 'Point Reward  (%s)';
$_['text_order_id'] = 'ID Pemesanan: #%s';
$_['text_success']  = 'Sukses: Diskon poin reward Anda telah diterapkan!';

// Entry
$_['entry_reward']  = 'Poin yang digunakan (Maksimal %s)';

// Error
$_['error_reward']  = 'Peringatan: Harap masukkan jumlah poin reward untuk menggunakan!';
$_['error_points']  = 'Peringatan: Anda tidak punya %s point reward !';
$_['error_maximum'] = 'Peringatan: Jumlah maksimum poin yang dapat diterapkan adalah %s!';

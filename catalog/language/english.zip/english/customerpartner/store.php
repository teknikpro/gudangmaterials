<?php
// Heading 
$_['heading_title']     = 'Toko';

//Text

$_['text_profile'] = 'Lihat pemilik';
$_['text_store'] = 'Lihat toko';
$_['text_collection'] = 'Lihat koleksi lengkap';
$_['text_from'] = 'Kami dari';
$_['text_feedback'] = 'Umpan balik';
$_['text_connect'] = 'Hubungi kami';
$_['text_message'] = 'Kirim pesan';
$_['text_facebook'] = 'Cari kami di Facebook';
$_['text_twitter'] = 'Ikuti kami di Twitter';
$_['text_partner'] = 'Tentang toko';
$_['text_our_collection'] = 'Koleksi kami';
$_['text_more'] = 'Lihat lebih lanjut...';
$_['text_latest_product'] = 'Tambah produk terbaru';

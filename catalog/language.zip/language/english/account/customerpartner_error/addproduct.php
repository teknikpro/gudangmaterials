<?php
// Heading
$_['heading_title']     		= 'Tambahkan Produk Baru';
$_['heading_title_update']     	= 'Perbarui Produk';
$_['heading_title_productlist'] = 'Daftar Produk';
$_['heading_category'] = 'Pilih Kategori';

// Text
$_['text_soldlist_info']		 = 'Klik Saya untuk detail selengkapnya';
$_['text_account']     			 = 'Akun';
$_['text_product']  			 = 'Produk';
$_['text_product_details'] 		 = 'Rincian Produk';
$_['text_success']      		 = 'Keberhasilan: Produk Anda telah berhasil disimpan.';
$_['text_select']				 = 'Memilih';
$_['text_categories']		     = 'Kategori';
$_['text_add_image']		     = 'Menambahkan gambar';
$_['text_access']			     = 'Anda tidak berwenang mengedit produk ini !!';
$_['text_confirm']        		 = 'Memastikan :Apakah Anda ingin menghapus Produk(s) ?';
$_['text_product_preview']     = 'Pratinjau Produk';
$_['text_addcategory']         = 'Tambahkan kategori';

// Entry
$_['entry_productcategory']  	 = 'Kategori Produk';
$_['entry_productname']     	 = 'Nama Produk';
$_['entry_description_short']	 = 'Deskripsi meta';
$_['entry_stock'] 				 ='Kuantitas';
$_['entry_productmodel']	 	 ='Model';
$_['entry_specialprice']		 ='Harga spesial($)';
$_['entry_specialtimestart']	 ='Waktu Khusus Mulai';
$_['entry_specialtimeend']   	 ='Akhir Waktu Khusus';
$_['entry_seokeyword']			 ='Kata Kunci Seo';
$_['entry_stockavailable']  	 ='Status Kehabisan Stok';


$_['error_warning']      	 = 'Peringatan: Silakan isi semua kolom !!';
$_['error_extension']    	 = 'Peringatan: Silakan masukkan Ekstensi gambar yang valid !';
$_['error_size'] 		 	 = 'Silakan pilih Gambar ukuran kecil kurang dari ';
$_['error_filetype'] 		 = 'Jenis file kesalahan';
$_['error_filename'] 		 = 'Kesalahan Dalam Nama File';
$_['error_upload'] 		     = 'File Tidak Diunggah';

// Button
$_['button_add_attribute']   = 'AddAttribute';
$_['button_add_option']      = 'AddOption';
$_['button_add_option_value']= 'AddOptionValue';
$_['button_add_discount']    = 'AddDiscount';
$_['button_add_special']     = 'AddSpecial';
$_['button_add_image']       = 'AddImage';
$_['button_remove']          = 'Remove';
$_['button_insert']          = 'Add';
$_['button_copy']            = 'Copy';
$_['button_filter']          = 'Filter';
$_['button_continue']        = 'Save';
$_['button_back']            = 'Back';
$_['button_close']           = 'Close';

// Text
$_['text_success_update']    = 'Sukses: Anda berhasil memperbarui produk!';
$_['error_insufficient_cat'] = 'Paket keanggotaan Anda tidak memungkinkan Anda untuk menambahkan beberapa kategori di atas. Silakan periksa saldo keanggotaan Anda di <a href="{link}" target="_blank">membership page</a>".';

$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'Default';
$_['text_image_manager']     = 'Pengelola Gambar';
$_['text_browse']            = 'Jelajahi';
$_['text_clear']             = 'Bersih';
$_['text_option']            = 'Pilihan';
$_['text_option_value']      = 'Nilai Opsi';
$_['text_percent']           = 'Persentase';
$_['text_amount']            = 'Jumlah Tetap';
$_['text_enabled']           = 'Enable';
$_['text_disabled']          = 'Disable';
$_['text_choose']            = 'Memilih';
$_['text_input']             = 'memasukkan';
$_['text_file']              = 'File';
$_['text_date']              = 'Tanggal';
$_['text_edit']              = 'Edit';
$_['text_no_results']        = 'Tidak Ditemukan Hasil !!';
$_['text_change_base']       = 'Klik Untuk Mengubah Gambar Dasar';

// Column
$_['column_name']            = 'Nama Produk';
$_['column_model']           = 'Model';
$_['column_image']           = 'Gambar';
$_['column_price']           = 'Harga';
$_['column_quantity']        = 'Kuantitas';
$_['column_sold']        	 = 'Jumlah Terjual';
$_['column_earned']          = 'Berpenghasilan';
$_['column_status']          = 'Status';
$_['column_action']          = 'Tindakan';

// Tab
$_['tab_general']            = 'General';
$_['tab_data']           	 = 'Data';
$_['tab_attribute']          = 'Attribute';
$_['tab_option']           	 = 'Option';
$_['tab_discount']        	 = 'Discount';
$_['tab_special']            = 'Special';
$_['tab_image']          	 = 'Images';
$_['tab_links']        		 = 'Links';

// Entry
$_['entry_name']             = 'Nama Produk';
$_['entry_meta_title'] 	 	 = 'Judul Tag Meta';
$_['entry_meta_keyword'] 	 = 'Kata Kunci Meta Tag';
$_['entry_meta_description'] = 'Deskripsi Tag Meta';
$_['entry_description']      = 'Deskripsi';
$_['entry_store']            = 'Toko';
$_['entry_keyword']          = 'Kata Kunci Seo';
$_['entry_model']            = 'Model';
$_['entry_sku']              = 'SKU';
$_['entry_upc']              = 'UPC';
$_['entry_ean']              = 'EAN';
$_['entry_jan']              = 'JAN';
$_['entry_isbn']             = 'ISBN';
$_['entry_mpn']              = 'MPN';
$_['entry_location']         = 'Lokasi';
$_['entry_shipping']         = 'Membutuhkan Pengiriman';
$_['entry_manufacturer']     = 'Pabrikan';
$_['entry_date_available']   = 'Tanggal Tersedia';
$_['entry_quantity']         = 'Kuantitas';
$_['entry_minimum']          = 'jumlah minimum';
$_['entry_stock_status']     = 'Status Kehabisan Stok';
$_['entry_price']            = 'Harga';
$_['entry_tax_class']        = 'Kelas Pajak';
$_['entry_points']           = 'Poin';
$_['entry_option_points']    = 'Poin';
$_['entry_subtract']         = 'kurangi stok';
$_['entry_weight_class']     = 'Kelas berat';
$_['entry_weight']           = 'Berat';
$_['entry_length']           = 'Kelas Panjang';
$_['entry_dimension']        = 'Ukuran (L x W x H)';
$_['entry_image']            = 'Gambar';
$_['entry_customer_group']   = 'Kelompok Pelanggan';
$_['entry_date_start']       = 'Tanggal Mulai';
$_['entry_date_end']         = 'Tanggal Berakhir';
$_['entry_priority']         = 'Prioritas';
$_['entry_attribute']        = 'Atribut';
$_['entry_attribute_group']  = 'Grup atribut';
$_['entry_text']             = 'Teks';
$_['entry_option']           = 'Pilihan';
$_['entry_option_value']     = 'Nilai Opsi';
$_['entry_required']         = 'Wajib';
$_['entry_status']           = 'Status';
$_['entry_sort_order']       = 'Sortir Pesanan';
$_['entry_category']         = 'Kategori';
$_['entry_filter']           = 'Filter';
$_['entry_download']         = 'Unduh';
$_['entry_related']          = 'Produk-produk terkait';
$_['entry_tag']          	 = 'Label Produk';
$_['entry_layout']           = 'Layout Override';
$_['entry_profile']          = 'Profil';
// custom field
$_['text_custom_field']        	 = 'Custom Field';
$_['entry_select_option']        = 'Pilih opsi :';
$_['entry_select_date']          = 'Select Date :';
$_['entry_select_datetime']      = 'Select Date-Time :';
$_['entry_select_time']          = 'Select Time :';
$_['entry_enter_text']           = 'Enter Text :';

//help
$_['help_keyword'] 				= 'Jangan gunakan spasi alih-alih ganti spasi dengan - dan pastikan kata kunci tersebut unik secara global.';
$_['help_sku']					= 'Stock Keeping Unit';
$_['help_upc']					= 'Universal Product Code';
$_['help_ean']					= 'European Article Number';
$_['help_jan']					= 'Japanese Article Number';
$_['help_isbn']					= 'International Standard Book Number';
$_['help_mpn']					= 'Manufacturer Part Number';
$_['help_manufacturer']			= '(Autocomplete)';
$_['help_minimum']				= 'Force a minimum ordered quantity';
$_['help_stock_status']			= 'Status shown when a product is out of stock';
$_['help_points']				= 'Jumlah poin yang dibutuhkan untuk membeli barang ini. Jika Anda tidak ingin produk ini dibeli dengan poin biarkan 0.';
$_['help_category']				= '(Autocomplete)';
$_['help_filter']				= '(Autocomplete)';
$_['help_download']				= '(Autocomplete)';
$_['help_related']				= '(Autocomplete)';
$_['help_tag']					= 'Comma Separated';
$_['help_length']				= 'Length';
$_['help_width']				= 'Width';
$_['help_height']				= 'Height';
$_['help_weight']				= 'Weight';
$_['help_image']				= 'jpg/JPG, jpeg/JPEG, gif/GIF, png/PNG only';






$_['text_recurring_help']    = 'Jumlah berulang dihitung berdasarkan frekuensi dan siklus. <br />For example if you use a frequency of "week" and a cycle of "2", then the user will be billed every 2 weeks. <br />The length is the number of times the user will make a payment, set this to 0 if you want payments until they are cancelled.';
$_['text_recurring_title']   = 'Pembayaran berkala';
$_['text_recurring_trial']   = 'Periode Percobaan';
$_['entry_recurring']        = 'Penagihan Berulang:';
$_['entry_recurring_price']  = 'Harga Berulang:';
$_['entry_recurring_freq']   = 'Frekuensi Berulang:';
$_['entry_recurring_cycle']  = 'Siklus Berulang:<span class="help">How often its billed, must be 1 or more</span>';
$_['entry_recurring_length'] = 'Panjang Berulang:<span class="help">0 = until cancelled</span>';
$_['entry_trial']            = 'Periode percobaan:';
$_['entry_trial_price']      = 'Harga Percobaan Berulang:';
$_['entry_trial_freq']       = 'Frekuensi Berulang Percobaan:';
$_['entry_trial_cycle']      = 'Siklus Berulang Percobaan:<span class="help">How often its billed, must be 1 or more</span>';
$_['entry_trial_length']     = 'Percobaan Panjang Berulang:';

$_['text_length_day']        = 'Hari';
$_['text_length_week']       = 'Minggu';
$_['text_length_month']      = 'Bulan';
$_['text_length_month_semi'] = 'Setengah bulan';
$_['text_length_year']       = 'Tahun';

$_['error_warning_authenticate'] = 'Peringatan: Anda tidak diizinkan untuk melihat halaman ini, Silakan hubungi administrator situs!';$_['error_warning_mandetory']= ' Warning: This field is mandetory!';
$_['error_warning']          = ' Peringatan: Silakan periksa formulir dengan seksama untuk kesalahan!';
$_['error_permission']       = ' Peringatan: Anda tidak memiliki izin untuk memodifikasi produk!';
$_['error_name']             = ' Nama Produk harus lebih besar dari 3 dan kurang dari 255 karakter!';
$_['error_model']            = ' Model Produk harus lebih besar dari 3 dan kurang dari 64 karakter!';
$_['error_price']            = ' Harga produk harus lebih besar dari atau sama dengan nol dan hanya boleh berisi angka!';
$_['error_quantity']         = ' Kuantitas produk harus lebih besar dari atau sama dengan nol!';
$_['error_price_quantity']   = ' Kuantitas dan harga produk harus lebih besar dari atau sama dengan nol dan hanya boleh berisi angka!';
$_['error_meta_title']       = ' Judul Produk Meta harus lebih dari 3 dan kurang dari 64 karakter!';
$_['error_no_of_images']     = ' Peringatan: Gambar Produk lebih dari batas - ';
$_['error_keyword']          = 'Kata kunci SEO sudah digunakan!';
$_['error_category']         = 'Silakan tambahkan setidaknya satu kategori!';

// image file upload check error
$_['error_filename']   = 'Peringatan: Nama file harus antara 3 dan 255!';
$_['error_folder']     = 'Peringatan: Nama folder harus antara 3 dan 255!';
$_['error_exists']     = 'Peringatan: File atau direktori dengan nama yang sama sudah ada!';
$_['error_directory']  = 'Peringatan: Direktori tidak ada!';
$_['error_filetype']   = 'Peringatan: Jenis file salah!';
$_['error_upload']     = 'Peringatan: File tidak dapat diunggah karena alasan yang tidak diketahui!';

// membership code
$_['entry_expiring_date']	 ='Expiring date';
$_['entry_auto_relist']   	 ='Auto Re-list';
$_['entry_auto_relist_lable']			 ='Enable auto-relist';
$_['entry_relist_duration']  	 ='Listing Duration';

$_['text_relist']  	 ='Re-list';
$_['text_publish']   ='Publish';
$_['text_unpublish'] ='Unpublish';
$_['text_clone_product'] ='Clone';
$_['entry_list_header'] ='Klik di sini untuk melihat paket keanggotaan';
$_['text_no_listing_duration'] ='Tidak ada durasi cantuman';
?>

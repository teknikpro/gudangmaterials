<?php
// Heading
$_['heading_title'] = 'Informasi';

// Text
$_['text_contact']  = 'Hubungi kami';
$_['text_sitemap']  = 'Peta Situs';
<?php
// Heading
$_['heading_title'] = 'Halaman yang anda cari tidak ditemukan!';

// Text
$_['text_error']    = 'Halaman yang anda cari tidak ditemukan.';
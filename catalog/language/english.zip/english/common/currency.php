<?php
// Text
$_['text_currency'] = 'Mata Uang';
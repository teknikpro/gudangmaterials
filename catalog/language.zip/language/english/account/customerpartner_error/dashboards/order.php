<?php
// Heading
$_['heading_title'] = 'Total Pesanan';

// Text
$_['text_view']     = 'Lihat lebih banyak';
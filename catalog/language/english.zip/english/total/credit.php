<?php
$_['text_credit']   = 'Credit Toko';
$_['text_order_id'] = 'ID Pesanan : #%s';
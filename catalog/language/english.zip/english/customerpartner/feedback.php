<?php

$_['text_success']              = 'Ulasan berhasil anda kirim ke Penjual...';

//Text
$_['text_no_reviews'] = 'Tidak ada ulasan tersedia';
$_['text_no_feedbacks'] = 'Tidak ada masukan tersedia';
$_['text_ask_seller'] = 'Kontak ke Penjual';
$_['text_subject'] = 'Subyek';
$_['text_ask'] = 'Bertanya';
$_['text_write'] = 'Tambahkan tanggapan';
$_['text_note'] = '';
$_['entry_bad'] = 'Buruk';
$_['entry_good'] = 'Baik';
$_['entry_captcha'] = 'Masukkan The kode di The Box di bawah';
$_['text_loading'] = 'Loading';
$_['text_no_reivew'] = '<div class="mp-no-location-found text-danger warning"> tidak ada ulasan.</div>';
$_['text_price'] = 'Harga';
$_['text_value'] = 'Value';
$_['text_quality'] = 'Kualitas';
$_['text_nickname'] = 'Nama';
$_['text_sum_review'] = 'Ringkasan Review Anda';
$_['text_review'] = 'Komentar';
$_['text_rating'] = 'Peringkat';
$_['button_continue'] = 'Lanjut';
$_['text_login'] = 'Silahkan Login untuk menambahkan Ulasan';


$_['error_name'] = ' peringatan: nama harus antara 3 dan 25 karakter!';
$_['error_text'] = ' peringatan: komentar harus antara 25 dan 1000 karakter!';
$_['error_attribute'] = ' peringatan: semua tinjauan peringkat diperlukan!';
$_['error_price_rating'] = 'Pilih harga umpan balik rating!';
$_['error_quality_rating'] = 'Pilih kualitas umpan balik rating!';
$_['error_value_rating'] = 'Pilih nilai umpan balik rating!';
$_['error_captcha'] = ' peringatan: kode verifikasi tidak sesuai dengan gambar!';

